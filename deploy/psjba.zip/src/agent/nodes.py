"""LangGraph 노드 함수 — call_model, execute_tool, assess_error."""

import json
import logging
import re
import time
from typing import Any, Optional

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.language_models import BaseChatModel

from src.agent.prompts import build_system_prompt
from src.agent.state import AgentState

logger = logging.getLogger("psjba.agent.nodes")

ERROR_KEYWORDS = ("error", "failed", "exception", "not found", "timeout")
MIN_KEEP_MESSAGES = 10


def _apply_sliding_window(
    messages: list[BaseMessage],
    max_context: int,
    min_keep: int = MIN_KEEP_MESSAGES,
) -> list[BaseMessage]:
    """슬라이딩 윈도우를 적용하여 messages를 정리한다.

    system 메시지는 항상 유지.
    user 메시지 기준으로 max_context 초과 시 오래된 것부터 제거.
    min_keep개의 최근 user 메시지는 절대 제거하지 않음.
    assistant 메시지는 user 메시지에 종속되어 함께 제거됨.

    Args:
        messages: 전체 메시지 리스트
        max_context: 최대 user 메시지 수
        min_keep: 유지할 최소 최근 user 메시지 수

    Returns:
        정리된 메시지 리스트
    """
    if max_context <= 0:
        return messages

    system_msgs: list[BaseMessage] = []
    non_system: list[BaseMessage] = []
    for msg in messages:
        if isinstance(msg, SystemMessage):
            system_msgs.append(msg)
        else:
            non_system.append(msg)

    user_indices = [
        i for i, m in enumerate(non_system) if isinstance(m, HumanMessage)
        and m.additional_kwargs.get("role") != "developer"
    ]

    if len(user_indices) <= max_context:
        return messages

    cutoff_count = len(user_indices) - max_context
    cutoff_user_idx = user_indices[cutoff_count]

    keep_start = cutoff_user_idx + 1
    trimmed = non_system[keep_start:]

    if not trimmed:
        return messages

    result = system_msgs + trimmed
    return result


_TOOL_NAME_PATTERN = re.compile(
    r"^(browser_(?:navigate|click|type|select_option|hover|scroll|focus|"
    r"press_key|wait|new_tab|close_tab|switch_tab|list_tabs|"
    r"get_focused_tab|screenshot|snapshot|get_dom|"
    r"execute_script|click_by_ref)"
    r"|chrome_(?:health|start)"
    r"|cron_(?:add|list|edit|toggle|remove|to_session)"
    r"|memory_search|workspace_write|current_datetime)\(\)?$"
)


def _detect_text_tool_call(content: str) -> Optional[str]:
    """모델이 텍스트로 도구 이름만 출력했는지 감지한다.

    예: "browser_snapshot()" 또는 "chrome_health" 형태의 텍스트.
    tool_call 을 해야 하는데 텍스트로 출력한 경우를 식별.

    Returns:
        매칭된 도구 이름, 또는 None
    """
    clean = content.strip().rstrip(")")
    m = _TOOL_NAME_PATTERN.match(clean)
    return m.group(0) if m else None


def _extract_finish_reason(response: BaseMessage) -> str:
    """AIMessage.response_metadata 에서 finish_reason 추출.

    Returns:
        "finish_reason=stop" 형태, 또는 빈 문자열
    """
    meta = getattr(response, "response_metadata", {}) or {}
    finish_reason = meta.get("finish_reason") or meta.get("finish_details", {}).get("type")
    return f"finish_reason={finish_reason}" if finish_reason else ""


def _is_tool_error(result: str) -> bool:
    """도구 실행 결과가 오류인지 판단한다."""
    lower = result.lower()
    return any(kw in lower for kw in ERROR_KEYWORDS)


async def call_model(
    state: AgentState,
    llm: BaseChatModel,
    max_context_messages: int = 30,
    max_tool_calls: int = 30,
) -> dict[str, Any]:
    """LLM을 호출하여 다음 액션을 결정한다.

    슬라이딩 윈도우를 적용하고, 시스템 프롬프트에 동적 a11y 트리를 주입한다.
    tool_call_count 가 max_tool_calls 를 초과하면 즉시 종료한다.
    intervention_queue 가 있으면 실행 중 사용자 입력을 컨텍스트에 주입한다.

    Args:
        state: 현재 에이전트 상태
        llm: ChatOpenAI 인스턴스
        max_context_messages: 슬라이딩 윈도우 크기
        max_tool_calls: 한 프롬프트 당 최대 tool call 횟수

    Returns:
        상태 업데이트 딕셔너리 (messages 추가)
    """
    # ── intervention 큐 확인: 실행 중 사용자 입력을 메시지로 주입 ──
    queue = state.get("intervention_queue")
    injected_msgs: list[BaseMessage] = []
    if queue:
        while queue:
            text = queue.pop(0)
            logger.info("Injecting intervention: %s", text[:80])
            injected_msgs.append(HumanMessage(content=text))

    # 최대 tool call 횟수 초과 시 즉시 종료
    current_count = state.get("tool_call_count", 0)
    if current_count >= max_tool_calls:
        logger.warning(
            f"Tool call limit reached: {current_count}/{max_tool_calls}, ending"
        )
        return {
            "messages": [
                AIMessage(
                    content=(
                        f"최대 tool call 횟수({max_tool_calls}회)에 도달했습니다. "
                        f"작업을 완료하지 못했습니다. "
                        f"더 간단한 작업으로 나누어 다시 시도해 주세요."
                    )
                )
            ],
            "is_final": True,
        }
    messages = list(state.get("messages", []))

    messages = _apply_sliding_window(messages, max_context_messages)

    # 주입된 intervention 메시지를 LLM 컨텍스트에 추가
    if injected_msgs:
        messages = messages + injected_msgs

    a11y_tree = state.get("accessibility_tree", "(No page loaded)")
    system_prompt = build_system_prompt(a11y_tree)

    final_messages = [SystemMessage(content=system_prompt)] + messages

    logger.info(
        f"call_model: {len(final_messages)} messages "
        f"(window: {len(messages)} after sliding)"
    )

    # 마지막 메시지(사용자 입력 or 툴 결과) 요약 로그
    if messages:
        last = messages[-1]
        if isinstance(last, HumanMessage):
            logger.info(f"LLM request >> user: {last.content[:120]}")
        elif isinstance(last, ToolMessage):
            try:
                data = json.loads(last.content)
                logger.info(
                    f"LLM request >> tool result: "
                    f"{data.get('tool', '?')} | "
                    f"{(data.get('result', '') or '')[:100]}"
                )
            except (json.JSONDecodeError, TypeError):
                logger.info(f"LLM request >> tool result: {last.content[:120]}")
        elif isinstance(last, AIMessage):
            hints = ""
            if hasattr(last, "tool_calls") and last.tool_calls:
                hints = f" [{len(last.tool_calls)} tools]"
            logger.info(f"LLM request >> ai{hints}: {last.content[:120]}")

    call_start = time.monotonic()
    logger.debug("LLM call starting...")

    try:
        response = await llm.ainvoke(final_messages)
    except Exception as e:
        duration = time.monotonic() - call_start
        logger.error(f"LLM call failed after {duration:.1f}s: {e}")
        return {
            "messages": injected_msgs + [
                AIMessage(content=f"LLM error: {e}. Please try again.")
            ],
            "error_count": state.get("error_count", 0) + 1,
        }

    call_duration = time.monotonic() - call_start
    finish_str = _extract_finish_reason(response)

    has_tool_calls = hasattr(response, "tool_calls") and response.tool_calls
    if has_tool_calls:
        tool_names = [tc["name"] for tc in response.tool_calls]
        log_msg = (
            f"LLM response ({call_duration:.1f}s): "
            f"{len(response.tool_calls)} tool calls "
            f"→ {tool_names}"
        )
        if finish_str:
            log_msg += f" | {finish_str}"
        logger.info(log_msg)
    else:
        content = str(response.content or "").strip()
        log_msg = (
            f"LLM response ({call_duration:.1f}s): "
            f"\"{content[:200]}\""
        )
        if finish_str:
            log_msg += f" | {finish_str}"
        logger.info(log_msg)
        # 모델이 텍스트로 도구 이름만 출력한 경우 경고 (tool_call 누락)
        text_tool_match = _detect_text_tool_call(content)
        if text_tool_match:
            warn_msg = (
                f"⚠️ STOP: model output '{text_tool_match}' as text "
                f"instead of a tool_call. "
                f"tool_choice='any' may not be supported by this model."
            )
            if finish_str:
                warn_msg += f" [{finish_str}]"
            logger.warning(warn_msg)

    return {"messages": injected_msgs + [response]}


async def execute_tool(
    state: AgentState,
    tools: dict[str, Any],
) -> dict[str, Any]:
    """LLM이 요청한 도구 호출을 실행한다.

    Args:
        state: 현재 에이전트 상태
        tools: 도구 이름→callable 매핑 딕셔너리

    Returns:
        상태 업데이트 딕셔너리 (ToolMessage 추가, error_count 갱신)
    """
    messages = list(state.get("messages", []))
    error_count = state.get("error_count", 0)

    last_ai = None
    for msg in reversed(messages):
        if isinstance(msg, AIMessage) and hasattr(msg, "tool_calls") and msg.tool_calls:
            last_ai = msg
            break

    if last_ai is None:
        return {
            "messages": [
                ToolMessage(
                    content="No tool calls found in last AI message.",
                    tool_call_id="error",
                )
            ],
            "error_count": error_count + 1,
        }

    tool_messages: list[BaseMessage] = []
    any_error = False

    for tc in last_ai.tool_calls:
        tool_name = tc["name"]
        tool_args = tc.get("args", {})
        tool_id = tc["id"]

        start = time.monotonic()
        try:
            tool_func = tools.get(tool_name)
            if tool_func is None:
                result = f"Unknown tool: {tool_name}"
                any_error = True
            else:
                result = await tool_func.ainvoke(tool_args)
        except Exception as e:
            result = f"Tool execution error ({tool_name}): {e}"
            any_error = True
        duration_ms = int((time.monotonic() - start) * 1000)

        logger.info(
            f"Tool {tool_name}({tool_args}) → "
            f"{result[:200]}{'...' if len(str(result)) > 200 else ''} "
            f"({duration_ms}ms)"
        )

        if _is_tool_error(str(result)):
            any_error = True

        tool_msg_content = json.dumps(
            {
                "tool": tool_name,
                "result": str(result),
                "duration_ms": duration_ms,
                "status": "error" if any_error else "success",
            },
            ensure_ascii=False,
        )
        tool_messages.append(
            ToolMessage(content=tool_msg_content, tool_call_id=tool_id)
        )

    new_error_count = error_count + 1 if any_error else 0

    # tool call 횟수 증가 및 로그
    current_tool_count = state.get("tool_call_count", 0)
    tool_call_count = current_tool_count + len(last_ai.tool_calls)
    logger.info(
        f"Tool call progress: {tool_call_count} "
        f"(last batch: {len(last_ai.tool_calls)})"
    )

    updates: dict[str, Any] = {
        "messages": tool_messages,
        "tool_call_count": tool_call_count,
    }

    if any_error:
        updates["error_count"] = new_error_count
    else:
        updates["error_count"] = 0

    screenshot_path = state.get("last_screenshot_path", "")
    if not any_error:
        for tm in tool_messages:
            try:
                data = json.loads(tm.content)
                if data.get("tool") == "browser_screenshot":
                    updates["last_screenshot_path"] = data.get("result", "")
            except (json.JSONDecodeError, TypeError):
                pass

    return updates


def assess_error(
    state: AgentState,
    max_retries: int = 3,
) -> dict:
    """도구 실행 결과를 평가하여 상태를 업데이트한다.

    노드 반환값은 dict(state update) 여야 한다.
    라우팅은 graph.py 의 conditional edge(lambda state: ...) 가 담당한다.

    Args:
        state: 현재 에이전트 상태
        max_retries: 최대 재시도 횟수
    """
    error_count = state.get("error_count", 0)
    is_final = state.get("is_final", False)

    if is_final:
        logger.info("assess_error: is_final=True, ending")
        return {}

    if error_count == 0:
        logger.info("assess_error: no error, continue")
        return {}

    if error_count < max_retries:
        logger.info(
            "assess_error: error_count=%d, retrying (%d retries left)",
            error_count,
            max_retries - error_count,
        )
        return {}

    logger.warning(
        "assess_error: error_count=%d >= %d, giving up",
        error_count,
        max_retries,
    )
    return {
        "is_final": True,
        "messages": [
            AIMessage(
                content=(
                    f"I've encountered {error_count} consecutive errors and cannot "
                    f"complete the task. Please check the browser state and try again."
                )
            )
        ],
    }
