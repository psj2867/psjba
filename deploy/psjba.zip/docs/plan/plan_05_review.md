# 검토 및 결정 사항 기록

## 적용된 결정 사항

| # | 결정 | 적용 파일 | 상태 |
|---|------|----------|------|
| 1 | ~~세션 초기화 버튼: 우측 상단 작게~~ → **입력창 우측 🗑️ 아이콘** | plan_02_config_ui.md, plan_04_ops.md | ✅ |
| 2 | 크론 "마지막 실행 결과" 제거, 클릭 시 세션 로그 | plan_02_config_ui.md, plan_04_ops.md | ✅ |
| 3 | language 우선순위: psjba_meta 제거, config.ini로 통일 | plan_02_config_ui.md, plan_03_agent.md, plan_04_ops.md | ✅ |
| 4 | browser_screenshot 파일명: {yyyyMMdd-HHmmss}.png | plan_03_agent.md, plan_04_ops.md | ✅ |
| 5 | browser_close 제거, tab_close만 유지 | plan_03_agent.md | ✅ |
| 6 | memory_search: SQLite FTS5 사용 | plan_03_agent.md | ✅ |
| 7 | 슬라이딩 윈도우: system 제외, user 메시지 기준 | plan_03_agent.md | ✅ |
| 8 | LLM Provider: openrouter 기본, openai 호환, ini에 provider url | plan_02_config_ui.md, plan_03_agent.md | ✅ |
| 9 | compaction.py 사용 안 함 정리 | plan_04_ops.md | ✅ |
| 10 | requirements.txt: cryptography 추가 | plan_04_ops.md | ✅ |
| 11 | CDP connection_timeout: 기본 1초, ini 설정 | plan_02_config_ui.md | ✅ |
| 12 | Chrome 실행 옵션: --disable-blink-features=AutomationControlled | plan_03_agent.md | ✅ |
| 13 | psjba_session: type 필드(chat/cron) 추가 | plan_02_config_ui.md, plan_04_ops.md | ✅ |
| 14 | 세션 제목: 첫 메시지 앞 50자 | plan_02_config_ui.md | ✅ |
| 15 | **UI 완전 갈아엎음**: 메인 윈도우 심플화 (⚙️ + 🔗 Chrome 버튼 + 프롬프트), 설정은 QDialog(설정/CRON/로그 탭) | plan_02_config_ui.md, plan_01_core.md, plan_03_agent.md, plan_04_ops.md | ✅ |
| 16 | **Chrome 실행 정책 변경**: 시작 시 5초 테스트(자동 실행 안 함), 버튼 클릭 시 1초→실패→Chrome 실행 | plan_02_config_ui.md, plan_03_agent.md, plan_04_ops.md | ✅ |
| 17 | **ui/ 폴더 구조 변경**: main_window + settings_dialog + chat_widget + prompt_input | plan_04_ops.md | ✅ |
| 18 | **Provider 설정 제거**: OpenAI 호환 API만 사용하므로 provider 드롭다운 삭제, model 기본값 `qwen/qwen3.6-27b` | config.py, settings_dialog.py, llm_client.py | ✅ |
| 19 | **모던 다크 테마 디자인 리뉴얼**: 전체 UI 컬러/스타일 통일 (딥네이비 계열, 라운드 코너, 액센트 블루 #4FC3F7, 호버/포커스 효과) | settings_dialog.py, main_window.py, chat_widget.py, prompt_input.py | ✅ |
| 20 | **chrome_health / chrome_start 툴 추가**: AI가 Chrome 연결 상태를 파악(chrome_health)하고 필요 시 연결(chrome_start)할 수 있는 도구. chrome_health는 연결 안 됨 상태에서도 안전 호출 가능 | manager.py, tools.py, prompts.py | ✅ |

## 디자인 시스템 (v0.1)

### 컬러 팔레트
| 역할 | 색상 | 용도 |
|------|------|------|
| 배경 (기본) | `#1a1a2e` | QDialog, QMainWindow, QScrollArea |
| 카드/섹션 | `#1e1e3a` | QFrame sections, AI 메시지 |
| 입력 필드 | `#16213e` | QLineEdit, QComboBox, QSpinBox, QTextEdit, 버튼 기본 |
| 입력 포커스 | `#0f3460` | selection-background, 호버 배경 |
| 액센트 블루 | `#4FC3F7` | 포커스 테두리, 호버 테두리, 탭 선택, 툴팁 아이콘 |
| 액센트 그린 | `#66BB6A` | Chrome 연결 됨, 크론 활성 |
| 액센트 레드 | `#ff6b6b` | Chrome 연결 해제/중지 버튼 |
| 텍스트 | `#e0e0e0` | 기본 글자색 |
| 텍스트 (보조) | `#888` / `#aaa` | 부가 정보, 비활성 텍스트 |
| 테두리 | `#2a2a4a` | 기본 border |
| hover 배경 | `#252545` / `#1e2d50` | hover 시 배경색 |

### 디자인 원칙
- **둥근 모서리**: QFrame 10px, 버튼/입력필드 6px, QTab 8px
- **포커스 효과**: 모든 입력 필드/QComboBox/QSpinBox는 `:focus` 시 블루 테두리
- **호버 효과**: 모든 버튼/QFrame는 `:hover` 시 밝은 배경 + 블루 테두리
- **QCheckBox**: 커스텀 인디케이터 (18px 정사각형, 체크 시 블루)
- **QScrollBar**: 8px 얇은 스크롤바, 라운드 핸들
- **QTabBar**: 밑줄(underline) 스타일, 선택된 탭만 블루 밑줄
- **말풍선**: 유저=블루 계열(#0f3460), AI=딥네이비(#1e1e3a), 둥근 모서리 10px
- **툴팁**: `?` 원형 아이콘(18px) + 호버/툴팁 팝업 어두운 배경
- **툴팁 지연**: 200ms (기존 1초에서 단축)
